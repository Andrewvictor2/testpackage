# testpackage
This library was created as an example of how to puplish your own python package.

# How to insall
...